
# Explanation of Files and Structure

### Project Folder Structure
---
```plaintext
final_submission/
├── Part A - Specialised Inference/
│   ├── eight_school_custom.ipynb
│   ├── mab_bb_final.ipynb
│   ├── melle.ipynb
│   ├── poisson_log_poisson_models_part_A.jl
│   ├── Robust_final.ipynb
├── Part B - Generalised Inference/
│   ├── final_submission.ipynb
├── readme.md
├── report_group6.pdf
```
---

### **Report**
The report that briefly explains the motivating choices you made when implementing all the inference procedures can be found in the `report_group6.pdf` file.

---

### **Part A - Specialised Inference**
This folder contains individual notebooks developed by different team members for their respective models. Each notebook demonstrates specialised inference algorithms designed for specific models. 

- **`eight_school_custom.ipynb`**  
  - Author: Bram  
  - Description: Implements adaptive Metropolis-Hastings with custom steps for each random variable. Focuses on the Eight Schools problem.

- **`Robust_final.ipynb`**  
  - Author: Bram  
  - Description: This notebook includes robust inference using adaptive Metropolis-Hastings with custom steps for random variables.

- **`comb_reg_piecewise_const.ipynb`**  
  - Author: Melle  
  - Description: Contains models and out-of-the-box (OOTB) inference algorithms as well as model-specific algorithm for piecewise constant.

- **`poisson_log_poisson_models_part_A.jl`**  
  - Author: Petar  
  - Description: Implements models written in Julia for Poisson regression and log-Poisson models.

- **`mab_bb_final.ipynb`**  
  - Author: Alex  
  - Description: Implements Bayesian Multi-Armed Bandit (MAB) and Beta-Bernoulli models.

---

### **Part B - Generalised Inference**
This folder contains a single notebook for generalised inference approaches and comparison of inference algorithms across models.

- **`final_submission.ipynb`**  
  - Description: Includes a comparison of inference algorithms applied to models, with an emphasis on Effective Sample Size (ESS) evaluations.

---

## Notes
- For Part A, all notebooks/files are designed to run independently without additional configuration.
- For Part B, the `final_submission.ipynb` notebook should run without much hassle as well.

---
